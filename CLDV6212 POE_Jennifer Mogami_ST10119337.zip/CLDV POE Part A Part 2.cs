﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Queues;
using Azure.Messaging;

namespace POEPart2
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            string connectionString = "DefaultEndpointsProtocol=https;AccountName=cldvpoepart2jennifer;AccountKey=3BPdwV/5jrXqBeDVoRrz51Wt4q/iVitZSwwBRez5x5xqSUlezLNP1hbiufzsDb0Gv4TvJWPbx1tJ+AStbheDag==;EndpointSuffix=core.windows.net";
            
            string queueName = "cldv-queue";

            QueueClient queueclient = new QueueClient(connectionString, queueName);
            Console.WriteLine($"Creating Queue {queueName}");
            await queueclient.CreateAsync();

            Console.WriteLine("Messages are being added to the queue");
            await queueclient.SendMessageAsync("9908260124087: Gallagher Convention Center: 2022-06-23: 321543876");
            await queueclient.SendMessageAsync("91827364519: 2022-04-14: Dischem Mall Of Africa: 0111120142083");
            await queueclient.SendMessageAsync("91827364519: 2022-08-09: Clicks Mall Of Africa: 9908240452087");
            await queueclient.SendMessageAsync("91827364519: 2022-07-23: Gallagher Convention Centre: 6908290234083");
            await queueclient.SendMessageAsync("91827364519: 2022-01-04: Dischem Mall Of Africa: 6802240234083");


        }
    }
}
