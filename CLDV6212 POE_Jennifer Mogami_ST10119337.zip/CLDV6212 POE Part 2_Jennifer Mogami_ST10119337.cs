using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using System.ComponentModel;
using Dapper;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace CloudPartB
{
    public class Function1
    {
        [FunctionName("Function1")]
        public static async Task Run([QueueTrigger("cldv-queue", Connection = "cldvqueue")]string myQueueItem, ILogger log)
        {
            log.LogInformation($"C# Queue trigger function processed: {myQueueItem}");

            try
            {
                var connectionString = "Server=tcp:cldvpoepartb.database.windows.net,1433;Initial Catalog=cldvpartb;Persist Security Info=False;User ID=jennjenn;Password={Jennifer65};MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30";
                using (var connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    await connection.ExecuteAsync($"INSERT INTO [dbo].[Message] ([Log]) VALUES ('{myQueueItem}')");
                    log.LogInformation("MESSAGE HAS BEEN ADDED SUCCESSFULLY");
                }
            }
            catch
            {

            }
        }
    }
}
